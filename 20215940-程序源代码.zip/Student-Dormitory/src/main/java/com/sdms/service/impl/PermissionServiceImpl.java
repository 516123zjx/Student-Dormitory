package com.sdms.service.impl;

import com.sdms.service.PermissionService;
import org.springframework.stereotype.Service;

@Service
public class PermissionServiceImpl implements PermissionService {

}
