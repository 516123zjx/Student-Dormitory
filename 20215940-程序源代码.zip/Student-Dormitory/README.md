 修改 src/main/resources/application.yml 这个文件中的配置信息  

url: jdbc:mysql://localhost:3306/db_sdms?useSSL=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai
username: root                       <--这个要改成本地MySQL中的用户名
password: 123456                     <--这个要改成本地MySQL中的密码



picture:
  path: C:/Users/用户名/Desktop/Student-Dormitory-Management-System/picture-path/       <--这个要改成picture-path这个文件夹在你电脑上的绝对路径  



易错点1           path冒号空格C:/Users/ ...                        冒号和C之间必须有空格  

易错点2           路径必须是以盘符开头的绝对路径         路径必须要以左斜杠"/"结尾
```



(3)在MySQL中创建一个名叫db_sdms的数据库，字符集设置utf8。在新建的db_sdms数据库中运行db_sdms.sql这个SQL文件，目的是将表结构和初始化数据导入到数据库中。  
建议使用数据库连接工具navicat完成操作
     




管理员   username=admin   password=123

学生     username=01217   password=01217

注意:在数据库中密码采用了MD5加盐单向加密,盐值就是用户各自的username 




