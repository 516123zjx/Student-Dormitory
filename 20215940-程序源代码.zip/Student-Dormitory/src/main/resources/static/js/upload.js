// 设置图片上传的接口URL
var pictureUploadURL = 'http://localhost:8080/upload/';
