package com.sdms.service;

import com.sdms.entity.Permission;

public interface PermissionService extends BaseEntityService<Permission> {

}
