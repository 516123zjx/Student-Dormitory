var footerHTML = "<span style=\"margin-right: 36px\"><!----></span>" +
    "<span style=\"color:rgb(144, 145, 146)\"><!----></span>";
var footerDOM = document.getElementById("sdms-footer");
if (typeof footerDOM !== "undefined" && footerDOM != null) {
    footerDOM.innerHTML = footerHTML;
}